"""
Value Physics RRP Fairness Audit & Empirical Benchmarking Engine
Deliverable ID: VPE-54 | Alethekanon Research Institute — Division 2
Author: Jarrod Lyndsay Hamilton, Australia

Empirical testing suite for the Universal Price Equation (UPE):
  P = m1 * m2 * gamma(v_rel) * [(S * U) / (R_n * (1 - R_a))] + P_e + P_b

Calculates forward biophysical pricing, reverse-engineers observed commercial RRPs,
solves for extractive drag (R_a), and establishes objective Recommended Retail Prices
based on Difficulty (RRP/D).
"""

import math
import csv
from typing import Dict, Any, List

# Official Services Australia (20 Sep 2026), Fair Work Ombudsman (1 Jul 2026) & ABS (May 2026) Income Brackets
# Services Australia Fortnightly Rates converted to Weekly (/2.0):
Y_YA_AT_HOME_WEEKLY_AUD = 241.20          # Youth Allowance (Single 18+, living at parent home: $482.40/fn)
Y_YA_INDEPENDENT_WEEKLY_AUD = 338.60      # Youth Allowance (Single, living away from home: $677.20/fn)
Y_JSP_SINGLE_WEEKLY_AUD = 412.45          # JobSeeker Payment (Single, no children: $824.90/fn)
Y_DSP_BASELINE_WEEKLY_AUD = 618.85        # Disability Support Pension (Single 21+ max total: $1,237.70/fn) -> CANONICAL STRUCTURAL FLOOR
Y_NMW_NET_WEEKLY_AUD = 888.90             # National Minimum Wage Net Disposable (Gross $1,004.90/wk @ $26.44/hr, 38h)
Y_NMW_GROSS_WEEKLY_AUD = 1004.90          # National Minimum Wage Gross Full-Time (38h @ $26.44/hr, FWO 1 Jul 2026)
Y_MEDIAN_NET_WEEKLY_AUD = 1285.00         # All-Employees Net Disposable Weekly Income (Gross $1,579.20/wk, ABS May 2026)
Y_ALL_EMP_GROSS_WEEKLY_AUD = 1579.20      # All-Employees Average Weekly Total Earnings Gross (ABS May 2026)
Y_AWOTE_NET_WEEKLY_AUD = 1635.00          # Full-Time Adult AWOTE Net Disposable Weekly (Gross $2,083.70/wk, ABS May 2026)
Y_AWOTE_GROSS_WEEKLY_AUD = 2083.70        # Full-Time Adult Average Weekly Ordinary Time Earnings Gross (ABS May 2026)

AUSTRALIAN_INCOME_BRACKETS_WEEKLY_AUD = {
    "YA_At_Home": Y_YA_AT_HOME_WEEKLY_AUD,
    "YA_Away_From_Home": Y_YA_INDEPENDENT_WEEKLY_AUD,
    "JSP_Single": Y_JSP_SINGLE_WEEKLY_AUD,
    "DSP_Structural_Baseline": Y_DSP_BASELINE_WEEKLY_AUD,
    "NMW_Net_38hr": Y_NMW_NET_WEEKLY_AUD,
    "NMW_Gross_38hr": Y_NMW_GROSS_WEEKLY_AUD,
    "All_Employees_Net": Y_MEDIAN_NET_WEEKLY_AUD,
    "All_Employees_Gross": Y_ALL_EMP_GROSS_WEEKLY_AUD,
    "FT_AWOTE_Net": Y_AWOTE_NET_WEEKLY_AUD,
    "FT_AWOTE_Gross": Y_AWOTE_GROSS_WEEKLY_AUD,
}

# Canonical defaults: DSP ($618.85/wk) is the true permanent non-working structural subsistence floor;
# All-Employees Net ($1,285.00/wk) / Median ($1,250.00/wk) and NMW ($1,004.90/wk gross, $26.44/hr) anchor wage comparisons.
DEFAULT_WEEKLY_DISPOSABLE_INCOME_AUD = 1250.00  # Regional NSW Median Weekly Disposable Income reference
DEFAULT_SUBSISTENCE_WEEKLY_INCOME_AUD = Y_DSP_BASELINE_WEEKLY_AUD  # $618.85/wk Disability Support Pension structural floor
STANDARD_WEEKLY_WORK_HOURS = 38.0               # Standard full-time Australian workweek (NES = 38.0 hours)
DEFAULT_NET_HOURLY_WAGE_AUD = DEFAULT_WEEKLY_DISPOSABLE_INCOME_AUD / STANDARD_WEEKLY_WORK_HOURS  # ~$32.8947/hr
NMW_HOURLY_WAGE_AUD = 26.44                     # Official FWO National Minimum Wage ($26.44/hr from 1 July 2026)

def calculate_gamma(v_rel: float, eps: float = 1e-16) -> float:
    """Calculates the relativistic urgency/coercion factor gamma(v_rel)."""
    v_capped = min(max(v_rel, 0.0), 1.0 - eps)
    return 1.0 / math.sqrt(1.0 - v_capped**2)

def calculate_forward_upe(
    P_e: float,
    P_b: float,
    U: float,
    S: float = 1.0,
    R_n: float = 1.0,
    R_a: float = 0.0,
    m1: float = 1.0,
    m2: float = 1.0,
    v_rel: float = 0.0,
    eps: float = 1e-16
) -> float:
    """Computes forward price from biophysical, energetic, and metabolic difficulty inputs."""
    gamma = calculate_gamma(v_rel, eps)
    denom = max(R_n * (1.0 - min(R_a, 1.0 - eps)), eps)
    metabolic_tier = m1 * m2 * gamma * ((S * U) / denom)
    return metabolic_tier + P_e + P_b

# Stock-Flow Consistent (SFC) Destination Decomposition of Extractive Drag (Ra)
# Grounded in VPE-38 (sfc_model.py) Godley-Lavoie Flow-of-Funds Matrix & ABS/ACCC Sectoral Margin Audits:
SFC_EXTRACTIVE_SINK_SHARES = {
    "Sink_1_Compound_Debt_Interest_Service": 0.38,       # 38%: Corporate, infrastructure (RAB) & working-capital interest/debt service
    "Sink_2_Commercial_Property_REIT_Land_Rent": 0.27,   # 27%: Retail/industrial leases & port/terminal tolls (pledged to commercial mortgages)
    "Sink_3_Oligopoly_Dividends_Buybacks_EBIT": 0.22,    # 22%: Net oligopoly equity payouts & executive rent extraction
    "Sink_4_Speculative_Brokerage_AntiWork_Admin": 0.13, # 13%: Futures hedging desks, multi-tier middleman brokerage & non-productive admin
}

def decompose_extractive_drag_sinks(extractive_premium_aud: float) -> Dict[str, float]:
    """
    Decomposes the Extractive Premium (P_retail - RRP/D) into its four macroeconomic
    Stock-Flow Consistent (SFC) destination sinks, quantifying how much of the unfair
    price markup goes to servicing compound debt & bad/inflated asset valuations.
    """
    prem = max(0.0, extractive_premium_aud)
    s1 = prem * SFC_EXTRACTIVE_SINK_SHARES["Sink_1_Compound_Debt_Interest_Service"]
    s2 = prem * SFC_EXTRACTIVE_SINK_SHARES["Sink_2_Commercial_Property_REIT_Land_Rent"]
    s3 = prem * SFC_EXTRACTIVE_SINK_SHARES["Sink_3_Oligopoly_Dividends_Buybacks_EBIT"]
    s4 = prem * SFC_EXTRACTIVE_SINK_SHARES["Sink_4_Speculative_Brokerage_AntiWork_Admin"]
    return {
        "Sink_1_Compound_Debt_Interest_AUD": round(s1, 4),
        "Sink_2_Commercial_Land_Rent_Mortgages_AUD": round(s2, 4),
        "Sink_3_Oligopoly_Dividends_EBIT_AUD": round(s3, 4),
        "Sink_4_Brokerage_AntiWork_Admin_AUD": round(s4, 4),
        "Combined_Debt_And_Mortgage_Service_Share_AUD": round(s1 + s2, 4),
        "Combined_Debt_And_Mortgage_Service_Pct_Of_Drag": 65.0,
    }

def calculate_index_metrics(
    P_retail: float,
    rrp_d: float,
    weekly_income_Y: float = DEFAULT_WEEKLY_DISPOSABLE_INCOME_AUD,
    subsistence_income_Y: float = DEFAULT_SUBSISTENCE_WEEKLY_INCOME_AUD,
    weekly_hours: float = STANDARD_WEEKLY_WORK_HOURS,
    eps: float = 1e-16
) -> Dict[str, float]:
    """
    Computes the Income Normalised Difficulty Examination (INDEX) metrics:
    Expresses commercial RRP, fair biophysical RRP/D, and extractive rentier drag
    as relative shares (%) of disposable weekly income and working life minutes.
    """
    y_med = max(weekly_income_Y, eps)
    y_sub = max(subsistence_income_Y, eps)
    w_net = y_med / max(weekly_hours, eps)
    extractive_premium = max(0.0, P_retail - rrp_d)

    # Percentage of Weekly Disposable Income (Median Regional Earner)
    index_obs_med_pct = (P_retail / y_med) * 100.0
    index_rrpd_med_pct = (rrp_d / y_med) * 100.0
    index_toll_med_pct = (extractive_premium / y_med) * 100.0

    # Percentage of Weekly Subsistence / Minimum Income (Low-Income Earner)
    index_obs_sub_pct = (P_retail / y_sub) * 100.0
    index_rrpd_sub_pct = (rrp_d / y_sub) * 100.0
    index_toll_sub_pct = (extractive_premium / y_sub) * 100.0

    # Working Life Equivalent in Minutes (at Median Net Hourly Wage w_net)
    labor_min_obs = (P_retail / w_net) * 60.0
    labor_min_rrpd = (rrp_d / w_net) * 60.0
    labor_min_confiscated = (extractive_premium / w_net) * 60.0

    # Multi-Bracket Statutory Welfare & Wage Normalisations (% of Weekly Income)
    bracket_shares = {}
    for b_name, b_inc in AUSTRALIAN_INCOME_BRACKETS_WEEKLY_AUD.items():
        bracket_shares[f"INDEX_Obs_Pct_{b_name}"] = round((P_retail / b_inc) * 100.0, 4)
        bracket_shares[f"INDEX_RRPD_Pct_{b_name}"] = round((rrp_d / b_inc) * 100.0, 4)
        bracket_shares[f"INDEX_Toll_Pct_{b_name}"] = round((extractive_premium / b_inc) * 100.0, 4)

    # Minimum Wage Labor Minutes (at FWO National Minimum Wage $26.44/hr gross)
    nmw_min_obs = (P_retail / NMW_HOURLY_WAGE_AUD) * 60.0
    nmw_min_rrpd = (rrp_d / NMW_HOURLY_WAGE_AUD) * 60.0
    nmw_min_confiscated = (extractive_premium / NMW_HOURLY_WAGE_AUD) * 60.0

    out = {
        "INDEX_Observed_Pct_DSP_Baseline": round((P_retail / Y_DSP_BASELINE_WEEKLY_AUD) * 100.0, 4),
        "INDEX_RRPD_Pct_DSP_Baseline": round((rrp_d / Y_DSP_BASELINE_WEEKLY_AUD) * 100.0, 4),
        "INDEX_Extractive_Toll_Pct_DSP_Baseline": round((extractive_premium / Y_DSP_BASELINE_WEEKLY_AUD) * 100.0, 4),
        "INDEX_Observed_Pct_JSP_Single": round((P_retail / Y_JSP_SINGLE_WEEKLY_AUD) * 100.0, 4),
        "INDEX_RRPD_Pct_JSP_Single": round((rrp_d / Y_JSP_SINGLE_WEEKLY_AUD) * 100.0, 4),
        "INDEX_Extractive_Toll_Pct_JSP_Single": round((extractive_premium / Y_JSP_SINGLE_WEEKLY_AUD) * 100.0, 4),
        "INDEX_Observed_Pct_YA_Away": round((P_retail / Y_YA_INDEPENDENT_WEEKLY_AUD) * 100.0, 4),
        "INDEX_RRPD_Pct_YA_Away": round((rrp_d / Y_YA_INDEPENDENT_WEEKLY_AUD) * 100.0, 4),
        "INDEX_Extractive_Toll_Pct_YA_Away": round((extractive_premium / Y_YA_INDEPENDENT_WEEKLY_AUD) * 100.0, 4),
        "INDEX_Observed_Pct_Median_Income": round(index_obs_med_pct, 4),
        "INDEX_RRPD_Pct_Median_Income": round(index_rrpd_med_pct, 4),
        "INDEX_Extractive_Toll_Pct_Median_Income": round(index_toll_med_pct, 4),
        "INDEX_Observed_Pct_Subsistence_Income": round(index_obs_sub_pct, 4),
        "INDEX_RRPD_Pct_Subsistence_Income": round(index_rrpd_sub_pct, 4),
        "INDEX_Extractive_Toll_Pct_Subsistence_Income": round(index_toll_sub_pct, 4),
        "Labor_Minutes_Observed": round(labor_min_obs, 2),
        "Labor_Minutes_Fair_RRPD": round(labor_min_rrpd, 2),
        "Labor_Minutes_Confiscated": round(labor_min_confiscated, 2),
        "NMW_Labor_Minutes_Observed": round(nmw_min_obs, 2),
        "NMW_Labor_Minutes_Fair_RRPD": round(nmw_min_rrpd, 2),
        "NMW_Labor_Minutes_Confiscated": round(nmw_min_confiscated, 2),
    }
    out.update(bracket_shares)
    return out

def audit_commercial_rrp(
    commodity: str,
    unit: str,
    sector: str,
    P_retail: float,
    P_e: float,
    P_b: float,
    U: float,
    S: float = 1.0,
    R_n: float = 1.0,
    v_rel: float = 0.0,
    m1: float = 1.0,
    m2: float = 1.0,
    fair_reserve_Ra: float = 0.02,
    weekly_income_Y: float = DEFAULT_WEEKLY_DISPOSABLE_INCOME_AUD,
    subsistence_income_Y: float = DEFAULT_SUBSISTENCE_WEEKLY_INCOME_AUD,
    weekly_hours: float = STANDARD_WEEKLY_WORK_HOURS,
    eps: float = 1e-16
) -> Dict[str, Any]:
    gamma = calculate_gamma(v_rel, eps)
    p_phys = P_e + P_b
    spread = P_retail - p_phys
    w_num = m1 * m2 * gamma * S * U
    m_pure = w_num / max(R_n, eps)
    m_fair = (gamma * S * U) / max(R_n * (1.0 - fair_reserve_Ra), eps)
    
    if spread <= eps:
        implied_Ra = 0.0
    else:
        ratio = m_pure / spread
        implied_Ra = max(0.0, min(1.0 - ratio, 1.0))
        
    rrp_d = calculate_forward_upe(
        P_e=P_e,
        P_b=P_b,
        U=U,
        S=S,
        R_n=R_n,
        R_a=fair_reserve_Ra,
        m1=1.0,
        m2=1.0,
        v_rel=v_rel,
        eps=eps
    )
    
    extractive_premium = max(0.0, P_retail - rrp_d)
    fairness_index = min(1.0, rrp_d / max(P_retail, eps))
    index_metrics = calculate_index_metrics(
        P_retail=P_retail,
        rrp_d=rrp_d,
        weekly_income_Y=weekly_income_Y,
        subsistence_income_Y=subsistence_income_Y,
        weekly_hours=weekly_hours,
        eps=eps
    )
    
    prec = 4 if "nt-km" in unit else 2
    fmt = f".{prec}f"
    working_out_str = (
        f"[Step 1: Biophysical Base] P_phys = P_e (${P_e:{fmt}}) + P_b (${P_b:{fmt}}) = ${p_phys:{fmt}}; "
        f"[Step 2: Observed Spread] Delta_spread = P_retail (${P_retail:{fmt}}) - P_phys (${p_phys:{fmt}}) = ${spread:{fmt}}; "
        f"[Step 3: Lorentz Coercion] gamma({v_rel:.2f}) = 1/sqrt(1 - {v_rel:.2f}^2) = {gamma:.4f}; "
        f"[Step 4: Metabolic Numerator] W_num = gamma ({gamma:.4f}) * S ({S:.2f}) * U ({U:{fmt}}) = {w_num:.4f}; "
        f"[Step 5: Pure Metabolic Cost] M_pure = W_num ({w_num:.4f}) / R_n ({R_n:.2f}) = ${m_pure:.4f}; "
        f"[Step 6: Fair Metabolic Tier (Ra=0.02)] M_fair = M_pure (${m_pure:.4f}) / 0.98 = ${m_fair:.4f}; "
        f"[Step 7: Fair RRP/D] RRP/D = P_phys (${p_phys:{fmt}}) + M_fair (${m_fair:.4f}) = ${rrp_d:{fmt}}; "
        f"[Step 8: Implied Drag Ra] Ra = 1 - (M_pure ${m_pure:.4f} / Delta_spread ${spread:{fmt}}) = {implied_Ra*100.0:.1f}%; "
        f"[Step 9: Premium & Fairness] Delta_P = ${P_retail:{fmt}} - ${rrp_d:{fmt}} = ${extractive_premium:{fmt}}, "
        f"Fairness = (${rrp_d:{fmt}} / ${P_retail:{fmt}}) * 100 = {fairness_index*100.0:.1f}%; "
        f"[Step 10: DSP INDEX ($618.85/wk) & NMW ($26.44/hr)] "
        f"INDEX_Obs = {index_metrics['INDEX_Observed_Pct_DSP_Baseline']:.2f}%, "
        f"INDEX_RRPD = {index_metrics['INDEX_RRPD_Pct_DSP_Baseline']:.2f}%, "
        f"INDEX_Toll = {index_metrics['INDEX_Extractive_Toll_Pct_DSP_Baseline']:.2f}%, "
        f"Confiscated_NMW = {index_metrics['NMW_Labor_Minutes_Confiscated']:.2f} min"
    )
    
    res = {
        "commodity": commodity,
        "unit": unit,
        "sector": sector,
        "P_retail_observed": round(P_retail, prec),
        "P_energy_Pe": round(P_e, prec),
        "P_base_Pb": round(P_b, prec),
        "P_phys_Pe_plus_Pb": round(p_phys, prec),
        "Observed_Metabolic_Spread_Delta": round(spread, prec),
        "Metabolic_U": round(U, prec),
        "Scarcity_S": round(S, 2),
        "Regen_Capacity_Rn": round(R_n, 2),
        "Relativistic_Urgency_vrel": round(v_rel, 2),
        "Lorentz_Gamma": round(gamma, 4),
        "Unextracted_Metabolic_Numerator_W": round(w_num, 4),
        "Pure_Metabolic_Cost_M_pure": round(m_pure, 4),
        "Fair_Metabolic_Tier_M_fair": round(m_fair, 4),
        "RRP_D_recommended": round(rrp_d, prec),
        "Implied_Extractive_Drag_Ra": round(implied_Ra, 4),
        "Extractive_Premium_AUD": round(extractive_premium, prec),
        "Fairness_Index_Percent": round(fairness_index * 100.0, 1),
        "Step_By_Step_Working_Out": working_out_str,
    }
    res.update(index_metrics)
    return res

def get_australian_benchmark_dataset() -> List[Dict[str, Any]]:
    """Returns the comprehensive 71-commodity Australian empirical calibration dataset."""
    return [
        {
            "commodity": "Commercial Sliced White Bread (680g)",
            "unit": "loaf",
            "sector": "Sector 1 (Food / Subsistence)",
            "P_retail": 4.10,
            "P_e": 0.38,
            "P_b": 0.45,
            "U": 2.15,
            "S": 1.00,
            "R_n": 1.00,
            "v_rel": 0.05
        },
        {
            "commodity": "Milling Wheat (APW1 / ASW1)",
            "unit": "tonne",
            "sector": "Sector 1 (Food / Agricultural Feedstock)",
            "P_retail": 365.00,
            "P_e": 104.40,
            "P_b": 82.00,
            "U": 95.00,
            "S": 1.05,
            "R_n": 0.98,
            "v_rel": 0.02
        },
        {
            "commodity": "Fresh Full Cream Milk (Full Fat)",
            "unit": "litre",
            "sector": "Sector 1 (Food / Dairy Subsistence)",
            "P_retail": 2.10,
            "P_e": 0.31,
            "P_b": 0.48,
            "U": 0.75,
            "S": 1.05,
            "R_n": 0.95,
            "v_rel": 0.10
        },
        {
            "commodity": "Farmgate Beef Cattle Weaners (British Breed)",
            "unit": "kg liveweight",
            "sector": "Sector 1 (Food / Pastoral Livestock)",
            "P_retail": 3.85,
            "P_e": 0.42,
            "P_b": 1.15,
            "U": 1.25,
            "S": 1.15,
            "R_n": 0.85,
            "v_rel": 0.15
        },
        {
            "commodity": "Automotive Diesel Fuel (Ultra-Low Sulphur)",
            "unit": "litre",
            "sector": "Sector 2 (Energy / Liquid Fuels)",
            "P_retail": 2.15,
            "P_e": 0.32,
            "P_b": 0.92,
            "U": 0.35,
            "S": 1.08,
            "R_n": 0.90,
            "v_rel": 0.12
        },
        {
            "commodity": "Residential Grid Electricity (Single-Rate Flat)",
            "unit": "kWh",
            "sector": "Sector 2 (Energy / Power Utility)",
            "P_retail": 0.36,
            "P_e": 0.08,
            "P_b": 0.07,
            "U": 0.09,
            "S": 1.15,
            "R_n": 0.92,
            "v_rel": 0.08
        },
        {
            "commodity": "LPG Bottled Gas (45kg Domestic Cylinder)",
            "unit": "45kg cylinder",
            "sector": "Sector 2 (Energy / Liquid Petroleum Gas)",
            "P_retail": 165.00,
            "P_e": 29.40,
            "P_b": 58.36,
            "U": 28.50,
            "S": 1.15,
            "R_n": 0.88,
            "v_rel": 0.16
        },
        {
            "commodity": "Bulk Potable Water Cartage (Regional NSW)",
            "unit": "kL (1,000L)",
            "sector": "Sector 3 (Water / Municipal Subsistence)",
            "P_retail": 15.50,
            "P_e": 4.32,
            "P_b": 3.95,
            "U": 3.20,
            "S": 1.30,
            "R_n": 0.75,
            "v_rel": 0.25
        },
        {
            "commodity": "Domestic Waste Collection (Regional NSW)",
            "unit": "weekly bin lift",
            "sector": "Sector 3/5 (Municipal Sanitation & Care)",
            "P_retail": 9.33,
            "P_e": 2.45,
            "P_b": 1.85,
            "U": 2.15,
            "S": 1.20,
            "R_n": 0.72,
            "v_rel": 0.22
        },
        {
            "commodity": "Prescription Antibiotic (Amoxicillin 500mg, 20 Caps)",
            "unit": "dispensing course",
            "sector": "Sector 5 (Care / Essential Healthcare)",
            "P_retail": 16.50,
            "P_e": 2.10,
            "P_b": 3.20,
            "U": 5.80,
            "S": 1.20,
            "R_n": 0.94,
            "v_rel": 0.35
        },
        {
            "commodity": "Residential Structural Softwood Timber (MGP10 90x45mm Pine)",
            "unit": "lineal metre",
            "sector": "Sector 4 (Shelter / Building Construction)",
            "P_retail": 7.20,
            "P_e": 0.85,
            "P_b": 1.20,
            "U": 2.10,
            "S": 1.25,
            "R_n": 0.88,
            "v_rel": 0.15
        },
        {
            "commodity": "Pre-Mixed Ready-Mix Concrete (N20 20 MPa Structural)",
            "unit": "cubic metre",
            "sector": "Sector 4 (Shelter / Building Construction)",
            "P_retail": 295.00,
            "P_e": 62.00,
            "P_b": 78.00,
            "U": 58.00,
            "S": 1.15,
            "R_n": 0.85,
            "v_rel": 0.20
        },
        {
            "commodity": "Structural Steel Reinforcing Mesh (SL82, 6.0m x 2.4m Sheet)",
            "unit": "sheet (14.4 m2)",
            "sector": "Sector 4 (Shelter / Building Construction)",
            "P_retail": 128.00,
            "P_e": 28.50,
            "P_b": 36.80,
            "U": 22.50,
            "S": 1.12,
            "R_n": 0.82,
            "v_rel": 0.18
        },
        {
            "commodity": "Bulk Road Freight Transport (Newell Highway B-Double Corridor)",
            "unit": "net tonne-km",
            "sector": "Sector 2/4 (Logistics / Spatial Freight)",
            "P_retail": 0.12,
            "P_e": 0.03,
            "P_b": 0.03,
            "U": 0.02,
            "S": 1.10,
            "R_n": 0.92,
            "v_rel": 0.14
        },
        {
            "commodity": "Australian Merino Greasy Wool (19-Micron Fleece)",
            "unit": "kg clean",
            "sector": "Sector 1/4 (Agri-Fiber / Thermal Shelter)",
            "P_retail": 15.50,
            "P_e": 1.45,
            "P_b": 2.20,
            "U": 5.60,
            "S": 1.10,
            "R_n": 0.88,
            "v_rel": 0.08
        },
        {
            "commodity": "Domestic Broadband Data Transit (NBN 50/20 Mbps Tier)",
            "unit": "monthly service",
            "sector": "Sector 5/6 (Digital Infrastructure / Utilities)",
            "P_retail": 85.00,
            "P_e": 4.80,
            "P_b": 14.50,
            "U": 12.20,
            "S": 1.05,
            "R_n": 0.95,
            "v_rel": 0.15
        },
        {
            "commodity": "Prescription Salbutamol Inhaler (100mcg CFC-Free MDI, 200 Doses)",
            "unit": "inhaler unit",
            "sector": "Sector 5 (Care / Essential Healthcare)",
            "P_retail": 12.50,
            "P_e": 0.65,
            "P_b": 1.35,
            "U": 3.40,
            "S": 1.10,
            "R_n": 0.92,
            "v_rel": 0.40
        },
        {
            "commodity": "Urban Reticulated Potable Water (Municipal Pipeline Tariff)",
            "unit": "kL (1,000L)",
            "sector": "Sector 3 (Water / Municipal Utility)",
            "P_retail": 3.60,
            "P_e": 0.48,
            "P_b": 0.62,
            "U": 1.15,
            "S": 1.15,
            "R_n": 0.80,
            "v_rel": 0.20
        },
        {
            "commodity": "Commercial Broiler Chicken (Whole Fresh Dressed Bird)",
            "unit": "kg dressed",
            "sector": "Sector 1 (Food / Poultry Subsistence)",
            "P_retail": 4.50,
            "P_e": 0.46,
            "P_b": 1.68,
            "U": 1.15,
            "S": 1.05,
            "R_n": 0.95,
            "v_rel": 0.12
        },
        {
            "commodity": "Standard Extruded Clay Facing Bricks (Common Structural Masonry)",
            "unit": "1,000 bricks",
            "sector": "Sector 4 (Shelter / Building Construction)",
            "P_retail": 1150.00,
            "P_e": 278.00,
            "P_b": 182.00,
            "U": 185.00,
            "S": 1.12,
            "R_n": 0.82,
            "v_rel": 0.18
        },
        {
            "commodity": "Coarse Solar Sea Salt (Unrefined Food & Livestock Grade)",
            "unit": "25kg bag",
            "sector": "Sector 1/3 (Food / Mineral Subsistence)",
            "P_retail": 14.50,
            "P_e": 1.65,
            "P_b": 2.10,
            "U": 4.20,
            "S": 1.05,
            "R_n": 0.96,
            "v_rel": 0.06
        },
        {
            "commodity": "Raw Centrifugal Cane Sugar (Bulk Crystal Milling Feedstock)",
            "unit": "tonne",
            "sector": "Sector 1 (Food / Agricultural Carbohydrate)",
            "P_retail": 620.00,
            "P_e": 142.00,
            "P_b": 168.00,
            "U": 145.00,
            "S": 1.08,
            "R_n": 0.90,
            "v_rel": 0.05
        },
        {
            "commodity": "HDPE Rural Water Reticulation Pipe (32mm PN12.5, 100m Coil)",
            "unit": "100m coil",
            "sector": "Sector 3/4 (Water & Agricultural Infrastructure)",
            "P_retail": 245.00,
            "P_e": 48.50,
            "P_b": 68.00,
            "U": 38.00,
            "S": 1.10,
            "R_n": 0.88,
            "v_rel": 0.16
        },
        {
            "commodity": "Farmgate Canola Grain (Bulk Non-GM Oilseed)",
            "unit": "tonne",
            "sector": "Sector 1 (Food / Vegetable Oil & Protein Meal)",
            "P_retail": 685.00,
            "P_e": 118.50,
            "P_b": 215.00,
            "U": 112.00,
            "S": 1.08,
            "R_n": 0.92,
            "v_rel": 0.04
        },
        {
            "commodity": "Commercial FIBC Polypropylene Bulk Bags (1-Tonne Woven Container)",
            "unit": "bag",
            "sector": "Sector 1/4 (Agri-Logistics & Storage Infrastructure)",
            "P_retail": 24.50,
            "P_e": 4.20,
            "P_b": 5.90,
            "U": 4.80,
            "S": 1.08,
            "R_n": 0.90,
            "v_rel": 0.12
        },
        {
            "commodity": "Bulk Portland Cement (General Purpose GP Clinker)",
            "unit": "tonne",
            "sector": "Sector 4 (Shelter / Building Construction)",
            "P_retail": 345.00,
            "P_e": 112.00,
            "P_b": 84.00,
            "U": 56.00,
            "S": 1.12,
            "R_n": 0.78,
            "v_rel": 0.15
        },
        {
            "commodity": "Corrugated Galvanized Steel Roofing Sheets (Custom Orb 0.42mm BMT)",
            "unit": "lineal metre",
            "sector": "Sector 4 (Shelter / Building Envelope Roofing)",
            "P_retail": 21.50,
            "P_e": 4.85,
            "P_b": 6.20,
            "U": 3.80,
            "S": 1.10,
            "R_n": 0.82,
            "v_rel": 0.18
        },
        {
            "commodity": "Bulk Granular Agricultural Urea Fertilizer (46% Nitrogen)",
            "unit": "tonne",
            "sector": "Sector 1/2 (Agricultural Biochemical Energy Feedstock)",
            "P_retail": 740.00,
            "P_e": 315.00,
            "P_b": 165.00,
            "U": 78.00,
            "S": 1.14,
            "R_n": 0.84,
            "v_rel": 0.15
        },
        {
            "commodity": "Agricultural Glyphosate Herbicide (450g/L SL Systemic Formulation)",
            "unit": "20L drum",
            "sector": "Sector 1/2 (Agricultural Chemical Inputs)",
            "P_retail": 135.00,
            "P_e": 22.50,
            "P_b": 54.00,
            "U": 21.50,
            "S": 1.12,
            "R_n": 0.86,
            "v_rel": 0.18
        },
        {
            "commodity": "Standard Gypsum Plasterboard Wall Lining (10mm Recessed Edge)",
            "unit": "1.2m x 2.4m sheet",
            "sector": "Sector 4 (Shelter / Building Interior Linings)",
            "P_retail": 24.80,
            "P_e": 4.90,
            "P_b": 6.40,
            "U": 4.10,
            "S": 1.10,
            "R_n": 0.85,
            "v_rel": 0.14
        },
        {
            "commodity": "Commercial Structural Hardwood Timber (F17 Kiln-Dried Hardwood, 90x45mm)",
            "unit": "lineal metre",
            "sector": "Sector 4 (Shelter / Structural Framing & Heavy Construction)",
            "P_retail": 14.80,
            "P_e": 2.15,
            "P_b": 2.85,
            "U": 3.20,
            "S": 1.25,
            "R_n": 0.72,
            "v_rel": 0.14
        },
        {
            "commodity": "Agricultural Feed Barley (F1 Broadacre Feed Grain)",
            "unit": "tonne",
            "sector": "Sector 1 (Food / Agricultural Feedstock & Livestock Energy)",
            "P_retail": 325.00,
            "P_e": 92.50,
            "P_b": 74.00,
            "U": 84.00,
            "S": 1.06,
            "R_n": 0.98,
            "v_rel": 0.04
        },
        {
            "commodity": "Commercial Copper Electrical Building Wire (2.5mm2 Twin & Earth Flat TPS Cable)",
            "unit": "100m drum",
            "sector": "Sector 2/4 (Energy Reticulation & Building Infrastructure)",
            "P_retail": 225.00,
            "P_e": 24.50,
            "P_b": 118.50,
            "U": 22.00,
            "S": 1.15,
            "R_n": 0.82,
            "v_rel": 0.18
        },
        {
            "commodity": "Solvent-Extracted Canola Meal / Protein Cake (Bulk Pelletized, 36%-38% Crude Protein)",
            "unit": "tonne",
            "sector": "Sector 1 (Food / Livestock Protein Feedstock & Nutrition)",
            "P_retail": 580.00,
            "P_e": 84.50,
            "P_b": 212.00,
            "U": 82.00,
            "S": 1.10,
            "R_n": 0.94,
            "v_rel": 0.10
        },
        {
            "commodity": "Commercial Hot-Rolled Structural Steel Universal Beams (150UB14.0)",
            "unit": "lineal metre",
            "sector": "Sector 4 (Shelter / Structural Steel Construction)",
            "P_retail": 52.00,
            "P_e": 11.20,
            "P_b": 14.50,
            "U": 8.20,
            "S": 1.12,
            "R_n": 0.82,
            "v_rel": 0.16
        },
        {
            "commodity": "Whole Ginned Cottonseed (Fuzzy White Cattle Feedstock)",
            "unit": "tonne",
            "sector": "Sector 1 (Food / Agricultural Protein Feedstock & Nutrition)",
            "P_retail": 520.00,
            "P_e": 86.50,
            "P_b": 178.50,
            "U": 68.00,
            "S": 1.14,
            "R_n": 0.90,
            "v_rel": 0.10
        },
        {
            "commodity": "Commercial Cold-Formed Steel Galvanized Framing / C-Purlin (C15015, 1.5mm BMT)",
            "unit": "lineal metre",
            "sector": "Sector 4 (Shelter / Structural Framing & Industrial Roofing)",
            "P_retail": 16.50,
            "P_e": 3.40,
            "P_b": 5.10,
            "U": 2.60,
            "S": 1.10,
            "R_n": 0.82,
            "v_rel": 0.16
        },
        {
            "commodity": "Australian Prime Hard Breadmaking Wheat (APH2 High-Protein Milling Grain, min 13% Protein)",
            "unit": "tonne",
            "sector": "Sector 1 (Food / Agricultural Feedstock)",
            "P_retail": 410.00,
            "P_e": 118.50,
            "P_b": 96.50,
            "U": 108.00,
            "S": 1.08,
            "R_n": 0.98,
            "v_rel": 0.04
        },
        {
            "commodity": "Commercial Aluminum Window Glazing Frames (Double-Glazed Residential Sliding Window, 1200mm x 1800mm Standard Unit)",
            "unit": "unit (2.16 m2)",
            "sector": "Sector 4 (Shelter / Fenestration & Building Envelope)",
            "P_retail": 540.00,
            "P_e": 52.00,
            "P_b": 168.00,
            "U": 64.80,
            "S": 1.14,
            "R_n": 0.84,
            "v_rel": 0.18
        },
        {
            "commodity": "Commercial Feed Sorghum (SGM1 Summer Grain Sorghum, min 9% Protein)",
            "unit": "tonne",
            "sector": "Sector 1 (Food / Agricultural Feedstock & Livestock Nutrition)",
            "P_retail": 360.00,
            "P_e": 104.50,
            "P_b": 82.00,
            "U": 92.00,
            "S": 1.08,
            "R_n": 0.98,
            "v_rel": 0.05
        },
        {
            "commodity": "Commercial Structural Steel Hollow Sections (100x100x4.0mm RHS/SHS, Grade C350LO)",
            "unit": "lineal metre",
            "sector": "Sector 4 (Shelter / Structural Framing & Post Columns)",
            "P_retail": 42.20,
            "P_e": 9.40,
            "P_b": 12.60,
            "U": 6.80,
            "S": 1.12,
            "R_n": 0.82,
            "v_rel": 0.16
        },
        {
            "commodity": "Australian Desi Chickpeas (CHKP1 Premium Bulk Pulse Grain)",
            "unit": "tonne",
            "sector": "Sector 1 (Food / Agricultural Legume Protein & Crop Rotation)",
            "P_retail": 710.00,
            "P_e": 135.00,
            "P_b": 145.00,
            "U": 114.00,
            "S": 1.15,
            "R_n": 1.04,
            "v_rel": 0.05
        },
        {
            "commodity": "Commercial Heavy Structural Steel Plate (Grade 250, 12mm Medium Plate, AS/NZS 3678)",
            "unit": "m2 (94.2 kg)",
            "sector": "Sector 4 (Shelter / Heavy Engineering & Civil Construction)",
            "P_retail": 220.70,
            "P_e": 52.50,
            "P_b": 64.50,
            "U": 34.00,
            "S": 1.10,
            "R_n": 0.82,
            "v_rel": 0.14
        },
        {
            "commodity": "Commercial Faba Beans (F1 Broadacre Pulse Grain, min 24% Protein)",
            "unit": "tonne",
            "sector": "Sector 1 (Food / Agricultural Pulse Protein & Human/Livestock Nutrition)",
            "P_retail": 455.00,
            "P_e": 118.00,
            "P_b": 98.00,
            "U": 98.00,
            "S": 1.08,
            "R_n": 1.05,
            "v_rel": 0.05
        },
        {
            "commodity": "Commercial Structural Steel Equal Angle (100x100x8.0mm EA, Grade 300PLUS / AS/NZS 3679.1)",
            "unit": "lineal metre",
            "sector": "Sector 4 (Shelter / Structural Steel Framing & Bracing)",
            "P_retail": 43.50,
            "P_e": 9.80,
            "P_b": 12.90,
            "U": 6.90,
            "S": 1.10,
            "R_n": 0.82,
            "v_rel": 0.16
        },
        {
            "commodity": "Australian Field Peas (Kaspa Type Bulk Grain / Livestock Protein Feed, min 22% Protein)",
            "unit": "tonne",
            "sector": "Sector 1 (Food / Agricultural Pulse Protein & Human/Livestock Nutrition)",
            "P_retail": 440.00,
            "P_e": 112.50,
            "P_b": 94.50,
            "U": 94.00,
            "S": 1.08,
            "R_n": 1.05,
            "v_rel": 0.05
        },
        {
            "commodity": "Commercial Structural Steel Parallel Flange Channel (150x75mm PFC, Grade 300PLUS / AS/NZS 3679.1)",
            "unit": "lineal metre",
            "sector": "Sector 4 (Shelter / Structural Steel Framing & Floor Joists)",
            "P_retail": 65.50,
            "P_e": 14.50,
            "P_b": 19.80,
            "U": 10.20,
            "S": 1.10,
            "R_n": 0.82,
            "v_rel": 0.16
        },
        {
            "commodity": "Australian Narrow-Leaf Lupins (Angustifolius Bulk Feed Lupins, min 32% Protein)",
            "unit": "tonne",
            "sector": "Sector 1 (Food / Agricultural Pulse Protein & High-Protein Feed)",
            "P_retail": 520.00,
            "P_e": 131.00,
            "P_b": 121.00,
            "U": 112.00,
            "S": 1.10,
            "R_n": 1.08,
            "v_rel": 0.05
        },
        {
            "commodity": "Commercial Galvanized Steel Built-In Lintel / T-Bar (200x10mm Lintel, AS/NZS 2699.3 / AS 4100)",
            "unit": "lineal metre",
            "sector": "Sector 4 (Shelter / Structural Masonry & Roof-Load Lintels)",
            "P_retail": 105.00,
            "P_e": 22.80,
            "P_b": 33.60,
            "U": 16.50,
            "S": 1.10,
            "R_n": 0.82,
            "v_rel": 0.18
        },
        {
            "commodity": "Australian Mungbeans (Berken / Crystal Type Pulse Grain, min 24% Protein)",
            "unit": "tonne",
            "sector": "Sector 1 (Food / Agricultural Pulse Protein & Summer Legume)",
            "P_retail": 1150.00,
            "P_e": 175.00,
            "P_b": 185.00,
            "U": 165.00,
            "S": 1.15,
            "R_n": 1.04,
            "v_rel": 0.08
        },
        {
            "commodity": "Commercial Structural Steel Parallel Flange Channel (200x75mm PFC, Grade 300PLUS / AS/NZS 3679.1)",
            "unit": "lineal metre",
            "sector": "Sector 4 (Shelter / Structural Steel Framing & Floor Bearers)",
            "P_retail": 85.00,
            "P_e": 18.80,
            "P_b": 25.60,
            "U": 13.20,
            "S": 1.10,
            "R_n": 0.82,
            "v_rel": 0.16
        },
        {
            "commodity": "Commercial De-Hulled Split Faba Beans (Machine Dressed Export & Food Grade, min 28% Protein)",
            "unit": "tonne",
            "sector": "Sector 1 (Food / Agricultural Pulse Protein & Human/Food Processing)",
            "P_retail": 750.00,
            "P_e": 226.00,
            "P_b": 156.00,
            "U": 138.00,
            "S": 1.12,
            "R_n": 1.05,
            "v_rel": 0.06
        },
        {
            "commodity": "Commercial Structural Steel Parallel Flange Channel (250x90mm PFC, Grade 300PLUS / AS/NZS 3679.1)",
            "unit": "lineal metre",
            "sector": "Sector 4 (Shelter / Structural Steel Framing & Heavy Transfer Bearers)",
            "P_retail": 132.00,
            "P_e": 29.20,
            "P_b": 39.70,
            "U": 20.40,
            "S": 1.10,
            "R_n": 0.82,
            "v_rel": 0.16
        },
        {
            "commodity": "Commercial De-Hulled Split Yellow Field Peas (Machine Dressed Food Grade, min 25% Protein)",
            "unit": "tonne",
            "sector": "Sector 1 (Food / Agricultural Pulse Protein & Human Food Processing)",
            "P_retail": 680.00,
            "P_e": 207.00,
            "P_b": 145.00,
            "U": 132.00,
            "S": 1.10,
            "R_n": 1.05,
            "v_rel": 0.05
        },
        {
            "commodity": "Commercial Structural Steel Parallel Flange Channel (300x90mm PFC, Grade 300PLUS / AS/NZS 3679.1)",
            "unit": "lineal metre",
            "sector": "Sector 4 (Shelter / Structural Steel Framing & Heavy Transfer Bearers)",
            "P_retail": 149.50,
            "P_e": 33.20,
            "P_b": 45.20,
            "U": 23.10,
            "S": 1.10,
            "R_n": 0.82,
            "v_rel": 0.16
        },
        {
            "commodity": "Commercial De-Hulled Split Red Lentils (Machine Dressed Export Grade, min 26% Protein)",
            "unit": "tonne",
            "sector": "Sector 1 (Food / Agricultural Pulse Protein & Human Food Processing)",
            "P_retail": 1050.00,
            "P_e": 262.00,
            "P_b": 178.00,
            "U": 146.00,
            "S": 1.15,
            "R_n": 1.05,
            "v_rel": 0.07
        },
        {
            "commodity": "Pharmaceutical Saline IV Infusion Bag (Sodium Chloride 0.9%, 1,000 mL)",
            "unit": "1,000 mL bag",
            "sector": "Sector 5 (Essential Care & Emergency Healthcare Consumables)",
            "P_retail": 8.50,
            "P_e": 0.65,
            "P_b": 0.85,
            "U": 2.40,
            "S": 1.20,
            "R_n": 0.90,
            "v_rel": 0.35
        },
        {
            "commodity": "Commercial Solar PV Module (440W Monocrystalline Residential Panel, Tier-1)",
            "unit": "440W panel",
            "sector": "Sector 2/4 (Renewable Energy Infrastructure & Building Envelope)",
            "P_retail": 165.00,
            "P_e": 38.50,
            "P_b": 52.00,
            "U": 14.50,
            "S": 1.08,
            "R_n": 0.88,
            "v_rel": 0.12
        },
        {
            "commodity": "Commercial Structural Steel Universal Column (200UC46.2, AS/NZS 3679.1 Grade 300PLUS)",
            "unit": "lineal metre",
            "sector": "Sector 4 (Shelter / Heavy Engineering & Structural Columns)",
            "P_retail": 172.00,
            "P_e": 38.50,
            "P_b": 52.00,
            "U": 26.50,
            "S": 1.10,
            "R_n": 0.82,
            "v_rel": 0.16
        },
        {
            "commodity": "Commercial Australian Faba Bean Protein Concentrate / Flour (min 55% Protein, per Tonne)",
            "unit": "tonne",
            "sector": "Sector 1 (Food / Agricultural Pulse Protein & Human Food Processing)",
            "P_retail": 1280.00,
            "P_e": 310.00,
            "P_b": 245.00,
            "U": 162.00,
            "S": 1.15,
            "R_n": 1.05,
            "v_rel": 0.06
        },
        {
            "commodity": "Commercial Structural Steel Universal Column (250UC72.9, AS/NZS 3679.1 Grade 300PLUS)",
            "unit": "lineal metre",
            "sector": "Sector 4 (Shelter / Heavy Engineering & Structural Columns)",
            "P_retail": 272.00,
            "P_e": 60.50,
            "P_b": 82.50,
            "U": 41.50,
            "S": 1.10,
            "R_n": 0.82,
            "v_rel": 0.16
        },
        {
            "commodity": "Commercial Australian Field Pea Protein Isolate (min 80% Protein, Spray-Dried, per Tonne)",
            "unit": "tonne",
            "sector": "Sector 1 (Food / Agricultural Pulse Protein & Human Food Processing)",
            "P_retail": 3450.00,
            "P_e": 820.00,
            "P_b": 615.00,
            "U": 385.00,
            "S": 1.15,
            "R_n": 1.05,
            "v_rel": 0.06
        },
        {
            "commodity": "Commercial Structural Steel Universal Column (310UC96.8, AS/NZS 3679.1 Grade 300PLUS)",
            "unit": "lineal metre",
            "sector": "Sector 4 (Shelter / Heavy Engineering & Structural Columns)",
            "P_retail": 360.00,
            "P_e": 80.50,
            "P_b": 109.50,
            "U": 55.00,
            "S": 1.10,
            "R_n": 0.82,
            "v_rel": 0.16
        },
        {
            "commodity": "Commercial Australian Chickpea Protein Isolate / Functional Flour (min 75% Protein, Alkaline-Extracted, per Tonne)",
            "unit": "tonne",
            "sector": "Sector 1 (Food / Agricultural Pulse Protein & Human Food Processing)",
            "P_retail": 3150.00,
            "P_e": 745.00,
            "P_b": 560.00,
            "U": 350.00,
            "S": 1.15,
            "R_n": 1.04,
            "v_rel": 0.06
        },
        {
            "commodity": "Commercial Deformed Steel Reinforcing Bar (N12 Rebar, Grade 500N, AS/NZS 4671, per Tonne)",
            "unit": "tonne",
            "sector": "Sector 4 (Shelter / Concrete Foundations & Reinforcing Infrastructure)",
            "P_retail": 1420.00,
            "P_e": 310.00,
            "P_b": 390.00,
            "U": 195.00,
            "S": 1.12,
            "R_n": 0.82,
            "v_rel": 0.16
        },
        {
            "commodity": "Commercial Deformed Steel Reinforcing Bar (N16 Rebar, Grade 500N, AS/NZS 4671, per Tonne)",
            "unit": "tonne",
            "sector": "Sector 4 (Shelter / Heavy Foundation & Civil Engineering)",
            "P_retail": 1380.00,
            "P_e": 295.00,
            "P_b": 390.00,
            "U": 185.00,
            "S": 1.10,
            "R_n": 0.82,
            "v_rel": 0.16
        },
        {
            "commodity": "Commercial Hot-Rolled Structural Steel Universal Beam (200UB22.3 Grade 300PLUS, per Lineal Metre)",
            "unit": "lineal metre",
            "sector": "Sector 4 (Shelter / Structural Steel Framing & Floor Bearers)",
            "P_retail": 82.50,
            "P_e": 18.20,
            "P_b": 24.80,
            "U": 12.80,
            "S": 1.10,
            "R_n": 0.82,
            "v_rel": 0.16
        },
        {
            "commodity": "Commercial Australian Kabuli Chickpeas (KBL1 Large 9mm/10mm Food Grade, per Tonne)",
            "unit": "tonne",
            "sector": "Sector 1 (Food / Agricultural Pulse & High-Value Export Legume)",
            "P_retail": 1280.00,
            "P_e": 165.00,
            "P_b": 210.00,
            "U": 175.00,
            "S": 1.15,
            "R_n": 1.04,
            "v_rel": 0.06
        },
        {
            "commodity": "Commercial Australian Cold-Pressed Canola Oil (Bulk Extra Virgin Food Grade, per 1,000L IBC)",
            "unit": "1,000L IBC",
            "sector": "Sector 1 (Food / Pure Vegetable Oil & Human Dietary Lipid)",
            "P_retail": 2650.00,
            "P_e": 480.00,
            "P_b": 640.00,
            "U": 220.00,
            "S": 1.12,
            "R_n": 0.94,
            "v_rel": 0.08
        },
        {
            "commodity": "Commercial Australian Malting Barley (G1 Premium Grade, per Tonne)",
            "unit": "tonne",
            "sector": "Sector 1 (Food / Agricultural Feedstock & Brewing Cereals)",
            "P_retail": 385.00,
            "P_e": 110.50,
            "P_b": 86.50,
            "U": 98.00,
            "S": 1.08,
            "R_n": 0.98,
            "v_rel": 0.05
        },
        {
            "commodity": "Commercial Australian Washed Brushed Potatoes (Sebago / Nadine 10kg Bag, Cooking Grade)",
            "unit": "10kg bag",
            "sector": "Sector 1 (Food / Staple Dietary Carbohydrate & Fresh Produce)",
            "P_retail": 12.50,
            "P_e": 1.85,
            "P_b": 2.45,
            "U": 2.40,
            "S": 1.10,
            "R_n": 0.92,
            "v_rel": 0.12
        },
        {
            "commodity": "Commercial Deformed Steel Reinforcing Bar (N20 Rebar, Grade 500N, AS/NZS 4671, per Tonne)",
            "unit": "tonne",
            "sector": "Sector 4 (Shelter / Heavy Civil Foundations & Infrastructure)",
            "P_retail": 1350.00,
            "P_e": 285.00, # EAF scrap melting electricity (~440 kWh/t), continuous bar rolling mill electric drives at 1,050 C, in-line Tempcore water quenching/tempering, flying shear cut-off, heavy bundling crane, flatbed delivery
            "P_b": 390.00, # 1.04t certified heavy structural steel scrap/billet feedstock ($335.00), V/Nb/Si-Mn micro-alloying for 500 MPa yield strength ($40.00), heavy bundle strapping, identification tags, timber dunnage ($15.00)
            "U": 175.00,   # Continuous caster operators, bar mill roll pass alignment technicians, Tempcore metallurgy QC testing, tensile yield and bend test metallurgists, overhead crane riggers, yard logistics
            "S": 1.10,     # Commercial construction schedule buffer and distributor stock
            "R_n": 0.82,   # Virgin iron ore and metallurgical coal depletion offset by high EAF secondary scrap recyclability
            "v_rel": 0.16  # Heavy civil pile cage and deep foundation pour critical path
        },
        {
            "commodity": "Commercial Australian Brown Onions (Cooking Grade, 10kg Bag)",
            "unit": "10kg bag",
            "sector": "Sector 1 (Food / Staple Dietary Allium & Fresh Produce)",
            "P_retail": 14.50,
            "P_e": 2.10,   # Precision broadacre bed-forming and vacuum seeder tractor diesel, drip/overhead irrigation pumping electricity (onions require 4-6 ML/ha), undercut lifting, field windrow drying exergy, packing shed mechanical topping/tailing, optical skin grading, air-curtain drying, transport linehaul
            "P_b": 2.80,   # Certified hybrid seed, basal NPK and micronutrient sulfur/zinc fertilizers, downy mildew fungicide regimes, mesh ventilation 10kg bags, wooden pallet depreciation
            "U": 2.70,     # Irrigation water scheduling, field harvest machine sorting crew, wash/dry shed optical sorter technicians, manual bag stitching and stacking, cold room humidity management, supermarket shelf stocking
            "S": 1.10,     # Regional seasonal harvest transitions and supermarket fresh supply buffer
            "R_n": 0.92,   # Annual intensive vegetable rotation requiring crop rotation to manage white rot
            "v_rel": 0.12  # Semi-perishable produce; cured onions store 2-3 months in ambient conditions
        }
    ]

def run_full_fairness_audit() -> List[Dict[str, Any]]:
    dataset = get_australian_benchmark_dataset()
    audited_results = []
    for item in dataset:
        res = audit_commercial_rrp(
            commodity=item["commodity"],
            unit=item["unit"],
            sector=item["sector"],
            P_retail=item["P_retail"],
            P_e=item["P_e"],
            P_b=item["P_b"],
            U=item["U"],
            S=item["S"],
            R_n=item["R_n"],
            v_rel=item["v_rel"]
        )
        audited_results.append(res)
    return audited_results

def audit_weekly_household_basket_index(
    weekly_income_Y: float = DEFAULT_WEEKLY_DISPOSABLE_INCOME_AUD,
    subsistence_income_Y: float = DEFAULT_SUBSISTENCE_WEEKLY_INCOME_AUD,
    weekly_hours: float = STANDARD_WEEKLY_WORK_HOURS
) -> Dict[str, Any]:
    """
    Evaluates the composite Weekly Household Subsistence Basket under the
    Income Normalised Difficulty Examination (INDEX) for a standard regional
    Australian household across Food, Fuel, Energy, Water, Sanitation, Care,
    Digital Utilities, and Amortized Shelter Maintenance.
    """
    audits_by_name = {a["commodity"]: a for a in run_full_fairness_audit()}
    basket_spec = [
        ("Commercial Sliced White Bread (680g)", 2.5, "loaves/wk"),
        ("Fresh Full Cream Milk (Full Fat)", 4.0, "litres/wk"),
        ("Commercial Broiler Chicken (Whole Fresh Dressed Bird)", 2.0, "kg/wk"),
        ("Automotive Diesel Fuel (Ultra-Low Sulphur)", 45.0, "litres/wk"),
        ("Residential Grid Electricity (Single-Rate Flat)", 115.0, "kWh/wk"),
        ("LPG Bottled Gas (45kg Domestic Cylinder)", 0.20, "cylinders/wk"),
        ("Urban Reticulated Potable Water (Municipal Pipeline Tariff)", 4.5, "kL/wk"),
        ("Domestic Waste Collection (Regional NSW)", 1.0, "lift/wk"),
        ("Domestic Broadband Data Transit (NBN 50/20 Mbps Tier)", 0.2308, "monthly plan/wk"),
        ("Prescription Antibiotic (Amoxicillin 500mg, 20 Caps)", 0.10, "course/wk"),
        ("Prescription Salbutamol Inhaler (100mcg CFC-Free MDI, 200 Doses)", 0.15, "inhaler/wk"),
        ("Residential Structural Softwood Timber (MGP10 90x45mm Pine)", 2.0, "m/wk maint"),
        ("Corrugated Galvanized Steel Roofing Sheets (Custom Orb 0.42mm BMT)", 0.5, "m/wk maint"),
        ("Standard Gypsum Plasterboard Wall Lining (10mm Recessed Edge)", 0.5, "sheet/wk maint"),
    ]
    total_obs = 0.0
    total_rrpd = 0.0
    items_breakdown = []
    for comm_name, qty, freq_label in basket_spec:
        a = audits_by_name[comm_name]
        cost_obs = a["P_retail_observed"] * qty
        cost_rrpd = a["RRP_D_recommended"] * qty
        prem = cost_obs - cost_rrpd
        total_obs += cost_obs
        total_rrpd += cost_rrpd
        items_breakdown.append({
            "commodity": comm_name,
            "weekly_quantity": qty,
            "unit_label": freq_label,
            "weekly_observed_AUD": round(cost_obs, 2),
            "weekly_fair_RRPD_AUD": round(cost_rrpd, 2),
            "weekly_extractive_toll_AUD": round(prem, 2),
            "item_INDEX_observed_pct_median": round((cost_obs / weekly_income_Y) * 100.0, 3),
            "item_INDEX_rrpd_pct_median": round((cost_rrpd / weekly_income_Y) * 100.0, 3),
            "item_INDEX_toll_pct_median": round((prem / weekly_income_Y) * 100.0, 3)
        })
    total_toll = total_obs - total_rrpd
    w_net = weekly_income_Y / weekly_hours
    w_sub = subsistence_income_Y / weekly_hours
    return {
        "weekly_median_income_AUD": weekly_income_Y,
        "weekly_subsistence_income_AUD": subsistence_income_Y,
        "net_median_hourly_wage_AUD": round(w_net, 2),
        "net_subsistence_hourly_wage_AUD": round(w_sub, 2),
        "total_weekly_observed_AUD": round(total_obs, 2),
        "total_weekly_fair_RRPD_AUD": round(total_rrpd, 2),
        "total_weekly_extractive_toll_AUD": round(total_toll, 2),
        "SFC_Extractive_Drag_Sinks_Weekly_AUD": decompose_extractive_drag_sinks(total_toll),
        "Basket_INDEX_Observed_Pct_Median_Income": round((total_obs / weekly_income_Y) * 100.0, 2),
        "Basket_INDEX_RRPD_Pct_Median_Income": round((total_rrpd / weekly_income_Y) * 100.0, 2),
        "Basket_INDEX_Extractive_Toll_Pct_Median_Income": round((total_toll / weekly_income_Y) * 100.0, 2),
        "Basket_INDEX_Observed_Pct_Subsistence_Income": round((total_obs / subsistence_income_Y) * 100.0, 2),
        "Basket_INDEX_RRPD_Pct_Subsistence_Income": round((total_rrpd / subsistence_income_Y) * 100.0, 2),
        "Basket_INDEX_Extractive_Toll_Pct_Subsistence_Income": round((total_toll / subsistence_income_Y) * 100.0, 2),
        "Weekly_Labor_Hours_Observed_Median": round(total_obs / w_net, 2),
        "Weekly_Labor_Hours_Fair_RRPD_Median": round(total_rrpd / w_net, 2),
        "Weekly_Labor_Hours_Confiscated_Median": round(total_toll / w_net, 2),
        "Weekly_Labor_Hours_Observed_Subsistence": round(total_obs / w_sub, 2),
        "Weekly_Labor_Hours_Fair_RRPD_Subsistence": round(total_rrpd / w_sub, 2),
        "Weekly_Labor_Hours_Confiscated_Subsistence": round(total_toll / w_sub, 2),
        "Bracket_Summary": {
            b_name: {
                "weekly_income_AUD": b_inc,
                "Basket_INDEX_Observed_Pct": round((total_obs / b_inc) * 100.0, 2),
                "Basket_INDEX_Fair_RRPD_Pct": round((total_rrpd / b_inc) * 100.0, 2),
                "Basket_INDEX_Extractive_Toll_Pct": round((total_toll / b_inc) * 100.0, 2),
                "Remaining_Weekly_Income_Observed_AUD": round(b_inc - total_obs, 2),
                "Remaining_Weekly_Income_Fair_RRPD_AUD": round(b_inc - total_rrpd, 2),
            }
            for b_name, b_inc in AUSTRALIAN_INCOME_BRACKETS_WEEKLY_AUD.items()
        },
        "items": items_breakdown
    }


def get_big4_bank_loan_benchmark_dataset() -> List[Dict[str, Any]]:
    """
    Returns the 5-Scale Big 4 Australian Bank (CBA, Westpac, NAB, ANZ) Loan & Credit
    Spread Benchmark Dataset (October 2026 RBA F5/F6/F7 & APRA ADI Telemetry),
    spanning Individual Unsecured Revolving Credit Cards, Individual Unsecured Personal
    Loans, Owner-Occupier Residential Mortgages, Small Business (SME) & Regional
    Agribusiness Secured Loans, and Large Corporate Institutional Syndicate Loans.
    """
    return [
        {
            "scale": "Scale 1: Individual Revolving Credit Card",
            "commodity": "Big 4 Individual Revolving Credit Card ($5,000 Balance @ 20.99% p.a.)",
            "unit": "month ($5k balance)",
            "sector": "Sector 6 (Financial Credit & Banking Enclosures — Scale 1: Individual Unsecured Revolving)",
            "principal_AUD": 5000.0,
            "nominal_rate_pct": 20.99,
            "P_retail": 90.46,  # $87.46 monthly interest (@ 20.99% p.a.) + $3.00 base monthly card fee ($36/yr)
            "P_e": 1.20,        # Automated card switch, NPP clearing & cloud data center exergy per account-month
            "P_b": 8.20,        # $0.70 IT hardware/card + $7.50 pure non-extractive mutual default reserve (1.80% p.a. actuarial loss pool on $5k)
            "U": 3.50,          # Automated KYC/AML, fraud monitoring & dispute call-center labor allocation (WEST-equiv/mo)
            "S": 1.02,          # Endogenous digital ledger credit creation (near-zero physical scarcity)
            "R_n": 0.98,        # Digital ledger clearing & mutual credit pool renewal capacity
            "v_rel": 0.32       # Acute household emergency liquidity urgency (medical, vehicle, or utility shortfall)
        },
        {
            "scale": "Scale 2: Individual Unsecured Personal Loan",
            "commodity": "Big 4 Individual Unsecured Personal Loan ($20,000 Facility @ 14.50% p.a.)",
            "unit": "month ($20k loan)",
            "sector": "Sector 6 (Financial Credit & Banking Enclosures — Scale 2: Individual Unsecured Term)",
            "principal_AUD": 20000.0,
            "nominal_rate_pct": 14.50,
            "P_retail": 253.67, # $241.67 monthly interest (@ 14.50% p.a.) + $12.00 monthly administration fee
            "P_e": 1.85,        # Core banking ledger, credit bureau API & settlement electricity per account-month
            "P_b": 21.50,       # $1.50 IT/origination amortization + $20.00 pure mutual default reserve (1.20% p.a. actuarial loss pool on $20k)
            "U": 6.80,          # Retail credit assessment, payslip verification & account servicing labor (WEST-equiv/mo)
            "S": 1.04,          # Retail consumer credit tier allocation
            "R_n": 0.96,        # Unsecured consumer repayment renewal capacity
            "v_rel": 0.25       # High household essential transport, medical, or debt-consolidation urgency
        },
        {
            "scale": "Scale 3: Owner-Occupier Residential Mortgage",
            "commodity": "Big 4 Owner-Occupier Residential Mortgage ($100,000 Tranche @ 6.46% p.a.)",
            "unit": "month ($100k tranche)",
            "sector": "Sector 6 (Financial Credit & Banking Enclosures — Scale 3: Individual Housing Mortgage)",
            "principal_AUD": 100000.0,
            "nominal_rate_pct": 6.46,
            "P_retail": 544.92, # $538.33 monthly interest (@ 6.46% p.a.) + $6.59 pro-rata monthly package fee ($395/yr on $500k loan)
            "P_e": 2.35,        # PEXA settlement, core banking server & offset ledger electricity per $100k tranche-month
            "P_b": 12.10,       # $2.10 title/IT infrastructure + $10.00 pure collateralized mortgage default reserve (0.12% p.a. loss floor per $100k)
            "U": 9.20,          # Mortgage underwriting, APRA serviceability buffer verification & valuation review per $100k (WEST-equiv/mo)
            "S": 1.05,          # First-mortgage residential land collateral backing
            "R_n": 0.98,        # Full collateral security & double-entry ledger regeneration
            "v_rel": 0.22       # Non-discretionary household shelter security & foreclosure avoidance urgency
        },
        {
            "scale": "Scale 4: Small Business (SME) & Agribusiness Loan",
            "commodity": "Big 4 Small Business (SME) & Agribusiness Loan ($100,000 Facility @ 7.72% p.a.)",
            "unit": "month ($100k facility)",
            "sector": "Sector 6 (Financial Credit & Banking Enclosures — Scale 4: SME & Regional Agribusiness)",
            "principal_AUD": 100000.0,
            "nominal_rate_pct": 7.72,
            "P_retail": 673.33, # $643.33 monthly interest (@ 7.72% p.a.) + $30.00 monthly commercial line/service fee
            "P_e": 2.90,        # Commercial payment gateway, BAS/covenant telemetry & branch network exergy per $100k-month
            "P_b": 32.10,       # $2.93 PPSR/commercial registry IT + $29.17 pure secured SME mutual default reserve (0.35% p.a. loss floor per $100k)
            "U": 13.80,         # Commercial relationship manager review, seasonal cashflow & tax return underwriting per $100k (WEST-equiv/mo)
            "S": 1.06,          # APRA SME risk-weighted capital allocation
            "R_n": 0.95,        # Regional productive enterprise revenue regeneration
            "v_rel": 0.16       # Working capital, payroll & seasonal planting/input purchase urgency
        },
        {
            "scale": "Scale 5: Large Corporate Institutional Syndicate",
            "commodity": "Big 4 Large Corporate Institutional Syndicate Loan ($100,000 Tranche @ 5.79% p.a.)",
            "unit": "month ($100k tranche)",
            "sector": "Sector 6 (Financial Credit & Banking Enclosures — Scale 5: Large Corporate Wholesale)",
            "principal_AUD": 100000.0,
            "nominal_rate_pct": 5.79,
            "P_retail": 485.83, # $482.50 monthly interest (@ 5.79% p.a.) + $3.33 pro-rata monthly syndicate agency fee
            "P_e": 1.60,        # Wholesale RITS/Austraclear settlement & institutional desk exergy per $100k tranche-month
            "P_b": 8.00,        # $1.33 wholesale legal/IT + $6.67 institutional default reserve (0.08% p.a. loss floor per $100k)
            "U": 6.20,          # Institutional credit desk covenant audit amortized across multi-million facility per $100k (WEST-equiv/mo)
            "S": 1.02,          # Prime corporate wholesale credit access
            "R_n": 0.98,        # High corporate cashflow & pricing pass-through renewal capacity
            "v_rel": 0.04       # Low urgency; high corporate bargaining symmetry & multi-bank tender competition
        }
    ]

def audit_big4_loan_spreads(rba_cash_rate_pct: float = 4.60) -> Dict[str, Any]:
    """
    Audits the fairness and regressive spread inversion of Australia's Big 4 banks
    (CBA, Westpac, NAB, ANZ) across all 5 borrower scales from Individual Unsecured
    to Large Corporate Wholesale, normalizing both on canonical monthly facilities
    and per $10,000 AUD borrowed per year.
    """
    loan_dataset = get_big4_bank_loan_benchmark_dataset()
    scales_summary = []
    for item in loan_dataset:
        a = audit_commercial_rrp(
            commodity=item["commodity"],
            unit=item["unit"],
            sector=item["sector"],
            P_retail=item["P_retail"],
            P_e=item["P_e"],
            P_b=item["P_b"],
            U=item["U"],
            S=item["S"],
            R_n=item["R_n"],
            v_rel=item["v_rel"]
        )
        principal = item["principal_AUD"]
        nominal_rate = item["nominal_rate_pct"]
        obs_mo = a["P_retail_observed"]
        fair_mo = a["RRP_D_recommended"]
        toll_mo = a["Extractive_Premium_AUD"]
        obs_annual = obs_mo * 12.0
        fair_annual = fair_mo * 12.0
        toll_annual = toll_mo * 12.0
        eff_obs_rate_pct = (obs_annual / principal) * 100.0
        fair_rrpd_rate_pct = (fair_annual / principal) * 100.0
        extractive_spread_pct = eff_obs_rate_pct - fair_rrpd_rate_pct
        rba_spread_bps = round((nominal_rate - rba_cash_rate_pct) * 100.0, 1)
        scale_factor_10k = 10000.0 / principal
        row = dict(a)
        mo_interest = round((principal * (nominal_rate / 100.0)) / 12.0, 2)
        mo_fee = round(obs_mo - mo_interest, 2)
        loan_working_out = (
            f"{a['Step_By_Step_Working_Out']}; "
            f"[Step 11: Loan Rate & Per-$10k Working Out] "
            f"Monthly Interest = (${principal:,.2f} * {nominal_rate:.2f}% / 12) = ${mo_interest:.2f} + Monthly Fee ${mo_fee:.2f} = ${obs_mo:.2f}/mo (${obs_annual:.2f}/yr); "
            f"Effective Rate = (${obs_annual:.2f} / ${principal:,.2f}) * 100 = {eff_obs_rate_pct:.2f}% p.a.; "
            f"Fair RRP/D Annual = ${fair_mo:.2f}/mo * 12 = ${fair_annual:.2f}/yr ({fair_rrpd_rate_pct:.2f}% p.a.); "
            f"Spread vs RBA Cash Rate ({rba_cash_rate_pct:.2f}%) = ({nominal_rate:.2f}% - {rba_cash_rate_pct:.2f}%) * 100 = +{rba_spread_bps:.1f} bps; "
            f"Per $10k Borrowed (scale factor {scale_factor_10k:.4f}): Obs = ${obs_annual * scale_factor_10k:.2f}/yr, "
            f"Fair RRP/D = ${fair_annual * scale_factor_10k:.2f}/yr, Extractive Toll = ${toll_annual * scale_factor_10k:.2f}/yr"
        )
        row.update({
            "scale": item["scale"],
            "principal_AUD": principal,
            "nominal_interest_rate_pct": nominal_rate,
            "effective_observed_rate_pct": round(eff_obs_rate_pct, 2),
            "fair_RRPD_rate_pct": round(fair_rrpd_rate_pct, 2),
            "unearned_extractive_rate_spread_pct": round(extractive_spread_pct, 2),
            "spread_over_RBA_cash_rate_bps": rba_spread_bps,
            "monthly_observed_AUD": round(obs_mo, 2),
            "monthly_fair_RRPD_AUD": round(fair_mo, 2),
            "monthly_extractive_toll_AUD": round(toll_mo, 2),
            "annual_cost_per_10k_borrowed_AUD": round(obs_annual * scale_factor_10k, 2),
            "annual_fair_RRPD_per_10k_borrowed_AUD": round(fair_annual * scale_factor_10k, 2),
            "annual_extractive_toll_per_10k_borrowed_AUD": round(toll_annual * scale_factor_10k, 2),
            "Loan_Step_By_Step_Working_Out": loan_working_out,
        })
        scales_summary.append(row)
    corp = scales_summary[-1]
    cc = scales_summary[0]
    pers = scales_summary[1]
    sme = scales_summary[3]
    return {
        "rba_cash_rate_pct": rba_cash_rate_pct,
        "credit_card_vs_corporate_rate_multiplier": round(cc["effective_observed_rate_pct"] / corp["effective_observed_rate_pct"], 2),
        "credit_card_vs_corporate_toll_per_10k_ratio": round(
            cc["annual_extractive_toll_per_10k_borrowed_AUD"] / corp["annual_extractive_toll_per_10k_borrowed_AUD"], 2
        ),
        "personal_loan_vs_corporate_rate_multiplier": round(pers["effective_observed_rate_pct"] / corp["effective_observed_rate_pct"], 2),
        "sme_vs_corporate_spread_bps": round((sme["nominal_interest_rate_pct"] - corp["nominal_interest_rate_pct"]) * 100.0, 1),
        "standard_500k_mortgage_monthly_interest_AUD": round(scales_summary[2]["monthly_observed_AUD"] * 5.0, 2),
        "standard_500k_mortgage_monthly_fair_RRPD_AUD": round(scales_summary[2]["monthly_fair_RRPD_AUD"] * 5.0, 2),
        "standard_500k_mortgage_monthly_extractive_toll_AUD": round(scales_summary[2]["monthly_extractive_toll_AUD"] * 5.0, 2),
        "scales": scales_summary
    }

if __name__ == "__main__":
    print("=" * 80)
    print("VALUE PHYSICS: UNIVERSAL PRICE EQUATION (UPE) EMPIRICAL RRP/D FAIRNESS AUDIT")
    print("Alethekanon Research Institute — Division 2 | Official Calibration Dataset (56 Goods)")
    print("=" * 80)
    
    audits = run_full_fairness_audit()
    for a in audits:
        p_ret = a["P_retail_observed"]
        pe = a["P_energy_Pe"]
        pb = a["P_base_Pb"]
        u = a["Metabolic_U"]
        rrpd = a["RRP_D_recommended"]
        ra = a["Implied_Extractive_Drag_Ra"] * 100
        prem = a["Extractive_Premium_AUD"]
        fair = a["Fairness_Index_Percent"]
        comm = a["commodity"]
        sec = a["sector"]
        unit = a["unit"]
        fmt = ".4f" if "nt-km" in unit else ".2f"
        print(f"Target Good: {comm}")
        print(f"  Sector: {sec} | Unit: {unit}")
        print(f"  Observed Retail RRP:  ${p_ret:{fmt}} AUD")
        print(f"  Energy Base (Pe):     ${pe:{fmt}} AUD")
        print(f"  Physical Base (Pb):   ${pb:{fmt}} AUD")
        print(f"  Metabolic Labor (U):  {u:{fmt}} WEST-equiv")
        print(f"  Fair RRP/D:           ${rrpd:{fmt}} AUD")
        print(f"  Extractive Drag (Ra): {ra:.1f}%")
        print(f"  Extractive Premium:   ${prem:{fmt}} AUD")
        print(f"  Fairness Index:       {fair:.1f}%")
        print()
    print("=" * 80)
