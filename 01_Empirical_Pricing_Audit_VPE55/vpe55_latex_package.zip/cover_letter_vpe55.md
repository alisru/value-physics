# Editorial Submission Cover Letter

**To:**  
Editor-in-Chief  
*Ecological Economics* (Elsevier)

**Date:** October 29, 2026  
**From:**  
Jarrod Lyndsay Hamilton  
Alethekanon Research Institute  
Division 2: Societal Economics & Macro-Micro Simulation  
Australia  
Email: jarrod@alethekanon.org  

**Subject:** Submission of Original Research Article: *"Empirical Case Study: Real-World Pricing, RRP/D Fairness Audit & Multi-Bracket INDEX — Food, Fuel, Energy, Shelter Materials, Essential Care, Agricultural Inputs, and Digital Infrastructure"* (Deliverable ID: `VPE-55`)

Dear Editor-in-Chief,

I am pleased to submit our original empirical research article, titled **"Empirical Case Study: Real-World Pricing, RRP/D Fairness Audit & Multi-Bracket INDEX — Food, Fuel, Energy, Shelter Materials, Essential Care, Agricultural Inputs, and Digital Infrastructure"**, for consideration for publication in *Ecological Economics*.

### Background & Scientific Contribution
Standard neoclassical microeconomic doctrine treats market price as an unobservable, subjective equilibrium scalar ($P = f(S, D)$), assuming that market transactions reflect voluntary utility maximization and allocative efficiency. However, this framework suffers from fundamental physical blind spots: it conceals irreversible thermodynamic exergy destruction, human metabolic labor exhaustion, and the asymmetric survival coercion inherent in purchasing non-discretionary subsistence goods.

Building on the theoretical foundations of Value Physics (*Hamilton, 2026*), this paper delivers the first complete empirical operationalization of the **Universal Price Equation (UPE)** and the **Multi-Bracket Income Normalised Difficulty Examination (INDEX)**:
$$P = m_1 \cdot m_2 \cdot \gamma(v_{\text{rel}}) \cdot \left[ \frac{S \cdot U}{R_n (1 - R_a)} \right] + P_e + P_b$$
We construct forward biophysical prices from the ground up, reverse-engineer observed commercial Recommended Retail Prices (RRP) to solve for institutional extractive drag ($R_a$), and evaluate the regressive incidence of pricing across **sixty-four foundational necessities** spanning seven essential provisioning sectors in eastern Australia: Food, Agriculture, Feed Grains, Protein Meals & Whole Oilseeds, Poultry, Sugar, Oilseeds, Agrochemicals & Fertilizers, Liquid Fuels, Power Utilities, Municipal Water/Sanitation, Essential Healthcare, Building Materials, Cold-Formed Steel Framing, Hot-Rolled Structural Beams, Copper Electrical Wire, Native Hardwood & Plantation Softwood Timber, Interior Drywall, Rural Reticulation Infrastructure, Spatial Freight Logistics, Agri-Fiber, and Digital Infrastructure.

Crucially, every price is evaluated through the Multi-Bracket INDEX anchored in official statutory welfare and wage brackets (Services Australia 20 Sep 2026; FWO 1 Jul 2026; ABS May 2026), establishing the **Disability Support Pension (DSP = $618.85/wk)** as the canonical non-working structural subsistence floor alongside Youth Allowance (YA), JobSeeker (JSP), National Minimum Wage (NMW), and Full-Time AWOTE.

### Key Empirical Findings
Grounded in official microdata from the Australian Bureau of Agricultural and Resource Economics and Sciences (ABARES), the Australian Bureau of Statistics (ABS), the Australian Energy Market Operator (AEMO), the Australian Competition and Consumer Commission (ACCC), the National Heavy Vehicle Regulator (NHVR), Australian Wool Innovation (AWI), and regional local government authorities, our findings reveal four distinct macroeconomic pricing regimes:
1. **Public and Municipal Essential Services (Bulk Water Cartage, Urban Reticulated Water, Domestic Waste Collection, Oral Antibiotics):** Characterized by high Biophysical Fairness Indices (78.4%–91.1\%) and low-to-moderate extractive drag ($R_a = 20.8\% - 32.5\%$). Pricing in these sectors directly tracks thermodynamic haulage and pumping exergy ($P_e$) and operator/clinical exertion ($U$), providing an uncorrupted biophysical baseline.
2. **Agricultural Subsistence Staples, Feed Grains, Poultry, Sugar & Primary Fibers (Bread, Wheat APW1, Prime Hard Wheat APH2, Barley, Canola Meal, Cottonseed, Milk, Broiler Chicken, Merino Wool, Raw Cane Sugar):** Exhibit intermediate-to-high extractive drag ($R_a = 34.2\% - 66.1\%$, with APH2 wheat achieving 38.9\% due to high nitrogen input absorption) and moderate fairness (67.9\%–82.1\%). Commercial grain and oilseed accumulation cartels and bulk logistics intermediaries extract substantial tolls across primary crops and livestock feeds: Milling Wheat ($R_a = 43.0\%$), Feed Barley ($R_a = 42.6\%$), Canola Grain ($R_a = 62.6\%$), Canola Protein Meal ($R_a = 66.0\%$), and Whole Fuzzy Cottonseed ($R_a = 66.1\%$). High-protein livestock supplements exhibit an identical ~66\% extraction drag across both oilseed meal and gin byproduct channels, compressing farmgate margins while inflating non-discretionary ration costs for dairy and beef producers.
3. **Corporate, Capital-Goods, Mineral Packaging, Rural Infrastructure, Energy Inputs & Patented Enclosures (Diesel Fuel, Steel Mesh, Ready-Mix Concrete, Portland Cement, Corrugated Steel Roofing, Gypsum Plasterboard, Copper Building Wire, Structural Universal Beams, Galvanized C-Purlins, Grid Electricity, Urea Fertilizer, Glyphosate Herbicide, Softwood Timber, Hardwood Timber, Road Freight, Clay Facing Bricks, Solar Sea Salt, Salbutamol Inhalers, HDPE Poly Pipe, FIBC Bulk Bags):** Characterized by severe extractive drag ($R_a = 41.4\% - 62.8\%$) and compressed Fairness Indices (52.2\%–80.9\%). Across residential housing construction materials, the complete structural building envelope, electrical reticulation, and interior linings audit confirms consistent institutional drag: foundation concrete ($R_a = 48.3\%$), reinforcing mesh ($R_a = 50.2\%$), plantation softwood framing timber ($R_a = 41.4\%$), structural kiln-dried hardwood timber ($R_a = 42.8\%$), masonry bricks ($R_a = 62.8\%$), steel roofing ($R_a = 50.4\%$), interior wall linings/gypsum plasterboard ($R_a = 60.3\%$), copper electrical building wire ($R_a = 61.8\%$), hot-rolled structural steel universal beams ($R_a = 56.9\%$), and cold-formed galvanized C-purlins ($R_a = 55.8\%$). In agricultural inputs, bulk urea fertilizer ($R_a = 58.8\%$), systemic glyphosate herbicide ($R_a = 51.3\%$), HDPE water pipe ($R_a = 62.5\%$), and FIBC bulk bags ($R_a = 59.7\%$) compound costs into broadacre farming.
4. **Natural Monopoly Digital Enclosures (Domestic Broadband Data Transit):** Represents the extreme frontier of institutional extraction, exhibiting an extractive drag fraction ($R_a = 79.2\%$) and an unprecedentedly low Fairness Index of 39.1\%. Wholesale broadband monopoly pricing and retail telecommunications packaging extract severe unearned financialized rents on essential civic connectivity.

### Multi-Bracket INDEX Analysis (DSP Anchoring)
Evaluating these commodities through the Multi-Bracket INDEX reveals extreme regressive incidence:
- For an Australian on the Disability Support Pension (DSP = $618.85/wk), standard domestic broadband ($85/mo) confiscates **13.74%** of weekly income (with **8.37%** pure extractive toll above physical RRP/D), compared to only **5.20%** of net weekly earnings for an AWOTE earner.
- Minimum wage workers must surrender **218 minutes** of labor weekly for broadband, of which **133 minutes** is confiscated by monopoly toll extraction.
- A weekly subsistence household food basket consumes **46.06%** of a DSP recipient's total income, but only **17.47%** for an average full-time wage earner, proving that supply chain sclerosis imposes a severely regressive tax on non-working citizens.

### Practical & Policy Relevance
By establishing an objective **Recommended Retail Price based on Difficulty (RRP/D)** coupled with the **Multi-Bracket INDEX**, this paper provides regulatory bodies (such as the ACCC) and community cooperative institutions (Cohesive Villages / Sovereign Mutual Credit Unions) with an ungameable, physically grounded standard to audit retail price gouging, enforce non-usurious commercial price corridors, and decouple essential goods from speculative financial exchanges.

### Manuscript Metadata & Compliance
- **Word Count:** ~13,500 words of formal expository text.
- **Display Items:** 1 Master Comparative Audit Table, 2 High-Resolution 300 DPI Publication Figures (`figure1_biophysical_breakdown.png` and `figure2_sclerosis_spectrum.png`).
- **Computational Reproducibility:** All findings are 100% reproducible via the open-source Python solver `rrp_fairness_audit.py` (verified with an automated unit test suite passing 61/61 tests).
- **Authorship & Conflicts of Interest:** This manuscript is original, has not been published previously, and is not under consideration elsewhere. The author declares no competing financial interests.
- **Open Access & Data Availability:** All data and code are licensed under Creative Commons Attribution 4.0 International (CC-BY 4.0).

Thank you for your consideration of this work. We look forward to the peer review process.

Sincerely,

**Jarrod Lyndsay Hamilton**  
Lead Researcher, Division 2: Societal Economics & Macro-Micro Simulation  
Alethekanon Research Institute  
Australia  
Email: jarrod@alethekanon.org  
